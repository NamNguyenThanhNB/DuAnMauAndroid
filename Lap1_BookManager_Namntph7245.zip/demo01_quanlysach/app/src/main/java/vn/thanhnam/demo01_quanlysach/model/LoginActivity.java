package vn.thanhnam.demo01_quanlysach.model;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import vn.thanhnam.demo01_quanlysach.R;

public class LoginActivity extends AppCompatActivity {
    private EditText edtUser, edtPass;
    private CheckBox cboSave;
    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        edtUser = findViewById(R.id.edtUser);
        edtPass = findViewById(R.id.edtPass);
        cboSave = findViewById(R.id.cboSave);
        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("BookManager");
        setSupportActionBar(toolbar);


    }

    public void loginBook(View view) {
        String user = edtUser.getText().toString().trim();
        String pass = edtPass.getText().toString().trim();
        if (user.equals("")) {
            edtUser.setError("tên đăng nhập rỗng");
            edtUser.requestFocus();
            return;
        } else if (pass.equals("")) {
            edtPass.setError("mật khẩu rỗng");
            edtPass.requestFocus();
            return;
        } else if (user.equals("admin") && pass.equals("admin")) {
            Intent intent = new Intent(LoginActivity.this, ManHinhChinh.class);
            startActivity(intent);
        } else {
            Toast.makeText(this, "Tài khoản hoặc mật khẩu của bạn không đúng mời thử lại", Toast.LENGTH_SHORT).show();
        }

    }

    public void cancelBook(View view) {
        edtUser.setText("");
        edtPass.setText("");
        cboSave.setChecked(false);
    }
}
