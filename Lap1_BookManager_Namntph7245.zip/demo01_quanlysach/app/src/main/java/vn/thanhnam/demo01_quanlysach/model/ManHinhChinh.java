package vn.thanhnam.demo01_quanlysach.model;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import vn.thanhnam.demo01_quanlysach.R;

public class ManHinhChinh extends AppCompatActivity {
    private Toolbar toolbar1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_man_hinh_chinh);
        toolbar1 = findViewById(R.id.toolbar1);
        toolbar1.setTitle("QUẢN LÝ SÁCH");
        setSupportActionBar(toolbar1);
    }

    public void openUser(View view) {
        Toast.makeText(this, "Người dùng", Toast.LENGTH_SHORT).show();
    }

    public void openTL(View view) {
        Toast.makeText(this, "Thể loại", Toast.LENGTH_SHORT).show();
    }

    public void openSach(View view) {
        Toast.makeText(this, "Sách", Toast.LENGTH_SHORT).show();
    }

    public void openHD(View view) {
        Toast.makeText(this, "Hóa đơn", Toast.LENGTH_SHORT).show();
    }

    public void openSachBC(View view) {
        Toast.makeText(this, "Sách bán chạy", Toast.LENGTH_SHORT).show();
    }

    public void openTK(View view) {
        Toast.makeText(this, "Thống kê", Toast.LENGTH_SHORT).show();
    }
}
