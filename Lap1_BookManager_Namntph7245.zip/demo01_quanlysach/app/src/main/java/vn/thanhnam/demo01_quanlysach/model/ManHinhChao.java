package vn.thanhnam.demo01_quanlysach.model;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import vn.thanhnam.demo01_quanlysach.R;

public class ManHinhChao extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_man_hinh_chao);

        final Thread thread = new Thread() {
            @Override
            public void run() {
                try {
                    Thread.sleep(1000);
                } catch (Exception e) {
                    Toast.makeText(ManHinhChao.this, "Error", Toast.LENGTH_SHORT).show();
                } finally {
                    Intent intent = new Intent(ManHinhChao.this, LoginActivity.class);
                    startActivity(intent);
                }
            }
        };
        thread.start();
    }
}
